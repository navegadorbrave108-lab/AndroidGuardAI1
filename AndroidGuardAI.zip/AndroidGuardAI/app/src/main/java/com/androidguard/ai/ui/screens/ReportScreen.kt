package com.androidguard.ai.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.androidguard.ai.domain.ReportBuilder
import com.androidguard.ai.domain.ReportSection
import com.androidguard.ai.ui.components.GuardCard
import com.androidguard.ai.ui.components.GuardList
import com.androidguard.ai.ui.components.ScreenTitle
import com.androidguard.ai.viewmodel.GuardViewModel

@Composable
fun ReportScreen(vm: GuardViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    // `remember` debe ejecutarse fuera del DSL de LazyColumn (que no es @Composable).
    val report = remember(state.lastScan) { state.lastScan?.let { ReportBuilder.build(it) } }

    GuardList {
        item { ScreenTitle("Informe final", "Generado con los datos reales del último análisis") }
        if (report == null) {
            item {
                GuardCard {
                    Text("Realiza un análisis desde Inicio para generar el informe.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = vm::runScan, enabled = !state.scanning, modifier = Modifier.fillMaxWidth()) {
                        Text(if (state.scanning) "Analizando…" else "ANALIZAR DISPOSITIVO")
                    }
                }
            }
        } else {
            items(report.sections) { section -> SectionCard(section) }
            item {
                Button(
                    onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, report.title)
                            putExtra(Intent.EXTRA_TEXT, report.toPlainText())
                        }
                        context.startActivity(Intent.createChooser(send, "Compartir informe"))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Compartir informe (tú eliges con quién)") }
            }
        }
    }
}

@Composable
private fun SectionCard(section: ReportSection) {
    GuardCard {
        Text(section.title, style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(6.dp))
        section.lines.forEach {
            Text(it, style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(vertical = 2.dp))
        }
    }
}
