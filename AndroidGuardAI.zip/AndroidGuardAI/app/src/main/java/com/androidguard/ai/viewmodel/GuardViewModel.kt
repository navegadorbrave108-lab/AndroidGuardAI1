package com.androidguard.ai.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.androidguard.ai.data.AppsSource
import com.androidguard.ai.data.DeviceInfoSource
import com.androidguard.ai.data.MemorySource
import com.androidguard.ai.data.ScanHistoryStore
import com.androidguard.ai.data.StorageSource
import com.androidguard.ai.domain.AppInfo
import com.androidguard.ai.domain.DeviceInfo
import com.androidguard.ai.domain.MemoryStats
import com.androidguard.ai.domain.RiskAnalyzer
import com.androidguard.ai.domain.RiskLevel
import com.androidguard.ai.domain.ScanResult
import com.androidguard.ai.domain.ScanSummary
import com.androidguard.ai.domain.StorageInfo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class GuardUiState(
    val device: DeviceInfo? = null,
    val storage: StorageInfo? = null,
    val memory: MemoryStats? = null,
    val apps: List<AppInfo> = emptyList(),
    val appsLoading: Boolean = false,
    val appsLoaded: Boolean = false,
    val appsSkipped: Int = 0,
    val appsNotes: List<String> = emptyList(),
    val scanning: Boolean = false,
    val scanProgress: Float = 0f,
    val scanStep: String = "",
    val scanError: String? = null,
    val lastScan: ScanResult? = null,
    val history: List<ScanSummary> = emptyList()
)

class GuardViewModel(application: Application) : AndroidViewModel(application) {

    private val deviceSource = DeviceInfoSource(application)
    private val storageSource = StorageSource()
    private val memorySource = MemorySource(application)
    private val appsSource = AppsSource(application)
    private val historyStore = ScanHistoryStore(application)

    private val _state = MutableStateFlow(GuardUiState())
    val state: StateFlow<GuardUiState> = _state.asStateFlow()

    init {
        _state.update { it.copy(history = historyStore.load()) }
        refreshDevice()
    }

    fun refreshDevice() {
        viewModelScope.launch(Dispatchers.Default) {
            val device = deviceSource.read()
            _state.update { it.copy(device = device) }
        }
    }

    fun refreshStorage() {
        viewModelScope.launch(Dispatchers.Default) {
            val storage = storageSource.read()
            _state.update { it.copy(storage = storage) }
        }
    }

    fun refreshMemory() {
        viewModelScope.launch(Dispatchers.Default) {
            val memory = memorySource.read()
            _state.update { it.copy(memory = memory) }
        }
    }

    fun ensureAppsLoaded() {
        val s = _state.value
        if (!s.appsLoaded && !s.appsLoading) refreshApps()
    }

    fun refreshApps() {
        if (_state.value.appsLoading) return
        viewModelScope.launch(Dispatchers.Default) {
            _state.update { it.copy(appsLoading = true) }
            try {
                val result = appsSource.load()
                _state.update {
                    it.copy(
                        apps = result.apps,
                        appsSkipped = result.skipped,
                        appsNotes = result.notes,
                        appsLoaded = true,
                        appsLoading = false
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update {
                    it.copy(appsLoading = false, appsNotes = listOf("Error al consultar las apps: ${e.message}"))
                }
            }
        }
    }

    /** Análisis real: cada paso lee datos del dispositivo; no hay resultados simulados. */
    fun runScan() {
        if (_state.value.scanning) return
        viewModelScope.launch(Dispatchers.Default) {
            _state.update {
                it.copy(scanning = true, scanProgress = 0.05f, scanError = null,
                    scanStep = "Leyendo información del dispositivo…")
            }
            try {
                val device = deviceSource.read()
                _state.update {
                    it.copy(device = device, scanProgress = 0.2f, scanStep = "Consultando almacenamiento…")
                }
                val storage = storageSource.read()
                _state.update {
                    it.copy(storage = storage, scanProgress = 0.35f, scanStep = "Consultando memoria RAM…")
                }
                val memory = memorySource.read()
                _state.update {
                    it.copy(memory = memory, scanProgress = 0.5f, scanStep = "Auditando aplicaciones instaladas…")
                }
                val appsResult = appsSource.load()
                _state.update {
                    it.copy(
                        apps = appsResult.apps,
                        appsSkipped = appsResult.skipped,
                        appsNotes = appsResult.notes,
                        appsLoaded = true,
                        scanProgress = 0.85f,
                        scanStep = "Evaluando indicadores de seguridad…"
                    )
                }
                val findings = RiskAnalyzer.analyze(device, storage, appsResult.apps)
                val status = RiskAnalyzer.overallStatus(findings)
                val userApps = appsResult.apps.count { !it.isSystem }
                val scan = ScanResult(
                    timestamp = System.currentTimeMillis(),
                    device = device,
                    storage = storage,
                    memory = memory,
                    appsReviewed = appsResult.apps.size,
                    userApps = userApps,
                    systemApps = appsResult.apps.size - userApps,
                    appsSkipped = appsResult.skipped,
                    findings = findings,
                    status = status
                )
                val history = historyStore.add(
                    ScanSummary(
                        timestamp = scan.timestamp,
                        appsReviewed = scan.appsReviewed,
                        high = scan.count(RiskLevel.HIGH),
                        medium = scan.count(RiskLevel.MEDIUM),
                        low = scan.count(RiskLevel.LOW),
                        info = scan.count(RiskLevel.INFO),
                        ramPercent = memory.percent,
                        storagePercent = storage.percent,
                        status = status
                    )
                )
                _state.update {
                    it.copy(
                        scanning = false,
                        scanProgress = 1f,
                        scanStep = "Análisis completado",
                        lastScan = scan,
                        history = history
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update {
                    it.copy(scanning = false, scanError = "El análisis falló: ${e.message ?: e.javaClass.simpleName}")
                }
            }
        }
    }
}
