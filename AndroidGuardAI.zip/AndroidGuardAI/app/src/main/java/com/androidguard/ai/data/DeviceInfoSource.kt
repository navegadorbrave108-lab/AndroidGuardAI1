package com.androidguard.ai.data

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import com.androidguard.ai.domain.DeviceInfo
import java.util.Locale

/** Lee datos del dispositivo con API oficiales. No requiere permisos. */
class DeviceInfoSource(private val context: Context) {

    fun read(): DeviceInfo {
        val battery: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val percent = if (level >= 0 && scale > 0) (level * 100) / scale else -1
        val status = battery?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val manufacturer = Build.MANUFACTURER.replaceFirstChar {
            if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString()
        }
        val userName = try {
            Settings.Global.getString(context.contentResolver, "device_name")
        } catch (e: Exception) {
            null
        }
        val displayName = if (!userName.isNullOrBlank()) userName else "$manufacturer ${Build.MODEL}"

        val keyguard = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager

        return DeviceInfo(
            displayName = displayName,
            manufacturer = manufacturer,
            model = Build.MODEL,
            androidRelease = Build.VERSION.RELEASE,
            sdkInt = Build.VERSION.SDK_INT,
            securityPatch = Build.VERSION.SECURITY_PATCH.takeIf { it.isNotBlank() },
            batteryPercent = percent,
            charging = charging,
            screenLockSecure = keyguard?.isDeviceSecure,
            usbDebugging = readGlobalFlag(Settings.Global.ADB_ENABLED),
            developerOptions = readGlobalFlag(Settings.Global.DEVELOPMENT_SETTINGS_ENABLED),
            testKeys = Build.TAGS?.contains("test-keys") == true
        )
    }

    private fun readGlobalFlag(name: String): Boolean? = try {
        Settings.Global.getInt(context.contentResolver, name, 0) == 1
    } catch (e: Exception) {
        null
    }
}
