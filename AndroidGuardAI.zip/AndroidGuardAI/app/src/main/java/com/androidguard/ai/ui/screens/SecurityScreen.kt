package com.androidguard.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.androidguard.ai.domain.Finding
import com.androidguard.ai.domain.RiskLevel
import com.androidguard.ai.ui.components.GuardCard
import com.androidguard.ai.ui.components.GuardList
import com.androidguard.ai.ui.components.ScreenTitle
import com.androidguard.ai.ui.components.Tag
import com.androidguard.ai.ui.components.TagRow
import com.androidguard.ai.ui.theme.color
import com.androidguard.ai.viewmodel.GuardViewModel

@Composable
fun SecurityScreen(vm: GuardViewModel, onOpenReport: () -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    val scan = state.lastScan

    GuardList {
        item { ScreenTitle("Analizador de seguridad", "Evaluación heurística local") }

        if (scan == null) {
            item {
                GuardCard {
                    Text(
                        "Todavía no hay resultados en esta sesión. El análisis lee datos reales del " +
                            "dispositivo; no se muestra ningún resultado de ejemplo.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = vm::runScan, enabled = !state.scanning, modifier = Modifier.fillMaxWidth()) {
                        Text(if (state.scanning) "Analizando…" else "ANALIZAR DISPOSITIVO", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            item {
                GuardCard {
                    Text("Estado: ${scan.status.label}", style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold, color = scan.status.color())
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LevelCount(RiskLevel.HIGH, scan.count(RiskLevel.HIGH), Modifier.weight(1f))
                        LevelCount(RiskLevel.MEDIUM, scan.count(RiskLevel.MEDIUM), Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LevelCount(RiskLevel.LOW, scan.count(RiskLevel.LOW), Modifier.weight(1f))
                        LevelCount(RiskLevel.INFO, scan.count(RiskLevel.INFO), Modifier.weight(1f))
                    }
                }
            }
            item {
                GuardCard {
                    Text("Amenazas confirmadas: 0", fontWeight = FontWeight.Bold)
                    Text(
                        "Android Guard AI no incluye un motor antimalware ni una base de firmas. " +
                            "Los hallazgos son indicadores que merecen revisión, no pruebas de que una app sea maliciosa.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            item {
                Button(onClick = onOpenReport, modifier = Modifier.fillMaxWidth()) { Text("Ver informe final") }
            }
            item {
                OutlinedButton(onClick = vm::runScan, enabled = !state.scanning, modifier = Modifier.fillMaxWidth()) {
                    Text(if (state.scanning) "Analizando…" else "Repetir análisis")
                }
            }
            if (scan.findings.isEmpty()) {
                item {
                    GuardCard { Text("No se encontraron indicadores con las reglas actuales.") }
                }
            }
            items(scan.findings) { FindingCard(it) }
        }
    }
}

@Composable
private fun LevelCount(level: RiskLevel, count: Int, modifier: Modifier) {
    Column(modifier) {
        Text("$count", style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold, color = level.color())
        Text(level.label, style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun FindingCard(f: Finding) {
    GuardCard {
        TagRow {
            Tag(f.level.label, f.level.color())
            Tag(f.kind.label, MaterialTheme.colorScheme.secondary)
        }
        Spacer(Modifier.height(8.dp))
        Text(f.title, fontWeight = FontWeight.Bold)
        if (f.appName != null) {
            Text("${f.appName} · ${f.packageName}", style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(4.dp))
        Text(f.detail, style = MaterialTheme.typography.bodyMedium)
    }
}
