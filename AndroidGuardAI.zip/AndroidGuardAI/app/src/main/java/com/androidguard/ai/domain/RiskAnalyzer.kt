package com.androidguard.ai.domain

import android.content.pm.ApplicationInfo
import java.time.LocalDate
import java.time.temporal.ChronoUnit

/**
 * Evaluación heurística basada únicamente en datos reales leídos del dispositivo.
 * No hay base de firmas de malware: los resultados son INDICADORES, nunca veredictos.
 */
object RiskAnalyzer {

    private val unusualCategories = setOf(
        ApplicationInfo.CATEGORY_GAME,
        ApplicationInfo.CATEGORY_AUDIO,
        ApplicationInfo.CATEGORY_VIDEO,
        ApplicationInfo.CATEGORY_IMAGE,
        ApplicationInfo.CATEGORY_NEWS
    )

    fun analyze(
        device: DeviceInfo,
        storage: StorageInfo?,
        apps: List<AppInfo>
    ): List<Finding> {
        val out = mutableListOf<Finding>()
        out += deviceFindings(device, storage)

        val outsideWithoutOtherFindings = mutableListOf<AppInfo>()
        for (app in apps.filter { !it.isSystem }) {
            val appFindings = analyzeApp(app)
            out += appFindings
            if (appFindings.isEmpty() && app.origin == InstallOrigin.OUTSIDE_KNOWN_STORES) {
                outsideWithoutOtherFindings += app
            }
        }
        if (outsideWithoutOtherFindings.isNotEmpty()) {
            val names = outsideWithoutOtherFindings.map { it.name }.sorted()
            val shown = names.take(15).joinToString(", ")
            val extra = if (names.size > 15) " y ${names.size - 15} más" else ""
            out += Finding(
                code = FindingCode.OUTSIDE_STORE_SUMMARY,
                level = RiskLevel.INFO,
                kind = FindingKind.PREVENTIVE_INFO,
                title = "${names.size} apps instaladas fuera de tiendas conocidas (sin otros indicadores)",
                detail = "Instalar desde otra fuente no implica que sean maliciosas, pero conviene " +
                    "confirmar que reconoces su origen: $shown$extra."
            )
        }
        return out.sortedWith(compareBy({ it.level.ordinal }, { it.appName ?: "" }))
    }

    /** Hallazgos de una sola app. Las apps del sistema no se evalúan. */
    fun analyzeApp(app: AppInfo): List<Finding> {
        if (app.isSystem) return emptyList()
        val res = mutableListOf<Finding>()
        val outside = app.origin == InstallOrigin.OUTSIDE_KNOWN_STORES
        val granted = app.sensitiveGranted
        val a11y = SpecialPrivilege.ACCESSIBILITY in app.specialActive
        val admin = SpecialPrivilege.DEVICE_ADMIN in app.specialActive
        val overlay = SpecialPrivilege.OVERLAY in app.specialActive
        val install = SpecialPrivilege.INSTALL_UNKNOWN in app.specialActive

        fun add(code: FindingCode, level: RiskLevel, kind: FindingKind, title: String, detail: String) {
            res += Finding(code, level, kind, title, detail, app.name, app.packageName)
        }

        if (a11y) {
            val reasons = mutableListOf<String>()
            if (outside) reasons += "instalada fuera de tiendas conocidas"
            if (overlay) reasons += "puede superponerse a otras apps"
            if (SensitiveCategory.SMS in granted) reasons += "tiene acceso a SMS"
            val high = reasons.isNotEmpty()
            add(
                FindingCode.ACCESSIBILITY,
                if (high) RiskLevel.HIGH else RiskLevel.MEDIUM,
                if (high) FindingKind.SUSPICIOUS_INDICATOR else FindingKind.GRANTED_PERMISSION,
                "Servicio de accesibilidad activo",
                "Un servicio de accesibilidad puede leer la pantalla y actuar en nombre del usuario. " +
                    "Es legítimo en muchas apps, pero es un privilegio muy potente." +
                    if (high) " Factores agravantes: ${reasons.joinToString(", ")}." else ""
            )
        }

        if (admin) {
            add(
                FindingCode.DEVICE_ADMIN,
                if (outside) RiskLevel.HIGH else RiskLevel.MEDIUM,
                if (outside) FindingKind.SUSPICIOUS_INDICATOR else FindingKind.GRANTED_PERMISSION,
                "Administrador de dispositivo activo",
                "Puede imponer políticas como bloqueo o borrado y dificultar su desinstalación." +
                    if (outside) " Además fue instalada fuera de tiendas conocidas." else ""
            )
        }

        if (overlay && !a11y) {
            add(
                FindingCode.OVERLAY,
                if (outside) RiskLevel.MEDIUM else RiskLevel.LOW,
                FindingKind.GRANTED_PERMISSION,
                "Superposición de pantalla permitida",
                "Puede dibujar sobre otras apps. Es habitual en burbujas y utilidades, pero también " +
                    "se usa para engañar al usuario."
            )
        }

        if (install) {
            add(
                FindingCode.INSTALL_UNKNOWN,
                if (outside) RiskLevel.MEDIUM else RiskLevel.LOW,
                FindingKind.GRANTED_PERMISSION,
                "Puede instalar aplicaciones desconocidas",
                "Tiene habilitada la instalación de paquetes APK. Desactívalo si no la necesitas para ello."
            )
        }

        if (outside && granted.isNotEmpty()) {
            val high = SensitiveCategory.SMS in granted || granted.size >= 3
            add(
                FindingCode.OUTSIDE_STORE_SENSITIVE,
                if (high) RiskLevel.HIGH else RiskLevel.MEDIUM,
                FindingKind.SUSPICIOUS_INDICATOR,
                "Origen no verificado con permisos sensibles",
                "Instalada fuera de tiendas conocidas (${app.installer ?: "instalador no registrado"}) " +
                    "con acceso concedido a: ${granted.joinToString(", ") { it.label }}."
            )
        }

        val sensitiveForCategory = granted.filter {
            it == SensitiveCategory.SMS || it == SensitiveCategory.CONTACTS || it == SensitiveCategory.CALL_LOG
        }
        if (app.category in unusualCategories && sensitiveForCategory.isNotEmpty()) {
            add(
                FindingCode.CATEGORY_MISMATCH,
                RiskLevel.MEDIUM,
                FindingKind.SUSPICIOUS_INDICATOR,
                "Permisos inusuales para su categoría declarada",
                "Declara la categoría «${categoryLabel(app.category)}» pero tiene acceso a: " +
                    "${sensitiveForCategory.joinToString(", ") { it.label }}."
            )
        }

        if ("android.permission.ACCESS_BACKGROUND_LOCATION" in app.grantedPermissions) {
            add(
                FindingCode.BACKGROUND_LOCATION,
                RiskLevel.LOW,
                FindingKind.GRANTED_PERMISSION,
                "Ubicación en segundo plano concedida",
                "Puede consultar tu ubicación incluso cuando no la estás usando."
            )
        }

        if (res.isEmpty() && granted.size >= 3) {
            add(
                FindingCode.MANY_SENSITIVE,
                RiskLevel.LOW,
                FindingKind.GRANTED_PERMISSION,
                "Varios permisos sensibles concedidos",
                "Acceso a: ${granted.joinToString(", ") { it.label }}. Comprueba que lo necesita."
            )
        }
        return res
    }

    private fun deviceFindings(d: DeviceInfo, s: StorageInfo?): List<Finding> {
        val r = mutableListOf<Finding>()

        val age = patchAgeDays(d.securityPatch)
        val note = "Solo se compara la fecha del parche instalado con la fecha actual; " +
            "la app no consulta servidores."
        when {
            age == null -> r += Finding(
                FindingCode.PATCH_UNKNOWN, RiskLevel.INFO, FindingKind.PREVENTIVE_INFO,
                "Parche de seguridad no disponible",
                "Este dispositivo no informó la fecha de su parche de seguridad."
            )
            age > 365 -> r += Finding(
                FindingCode.PATCH_OLD, RiskLevel.HIGH, FindingKind.SUSPICIOUS_INDICATOR,
                "Parche de seguridad con más de un año",
                "Fecha del parche: ${d.securityPatch} (hace $age días). $note"
            )
            age > 180 -> r += Finding(
                FindingCode.PATCH_OLD, RiskLevel.MEDIUM, FindingKind.SUSPICIOUS_INDICATOR,
                "Parche de seguridad con más de 6 meses",
                "Fecha del parche: ${d.securityPatch} (hace $age días). $note"
            )
        }

        if (d.screenLockSecure == false) {
            r += Finding(
                FindingCode.NO_SCREEN_LOCK, RiskLevel.MEDIUM, FindingKind.SUSPICIOUS_INDICATOR,
                "Sin bloqueo de pantalla seguro",
                "No hay PIN, patrón ni contraseña configurados. Cualquiera con acceso físico puede usar el teléfono."
            )
        }
        if (d.usbDebugging == true) {
            r += Finding(
                FindingCode.USB_DEBUGGING, RiskLevel.MEDIUM, FindingKind.SUSPICIOUS_INDICATOR,
                "Depuración USB activada",
                "Permite a un equipo conectado por USB acceder al dispositivo. Desactívala si no la usas."
            )
        } else if (d.developerOptions == true) {
            r += Finding(
                FindingCode.DEVELOPER_OPTIONS, RiskLevel.LOW, FindingKind.PREVENTIVE_INFO,
                "Opciones de desarrollador activadas",
                "No es un riesgo por sí mismo, pero amplía la superficie de configuración."
            )
        }
        if (d.testKeys) {
            r += Finding(
                FindingCode.TEST_KEYS, RiskLevel.MEDIUM, FindingKind.SUSPICIOUS_INDICATOR,
                "Sistema firmado con claves de prueba",
                "La compilación de Android usa «test-keys», habitual en ROMs personalizadas o dispositivos modificados."
            )
        }
        if (d.sdkInt <= 32) {
            r += Finding(
                FindingCode.OLD_ANDROID, RiskLevel.INFO, FindingKind.PREVENTIVE_INFO,
                "Versión de Android antigua (${d.androidRelease})",
                "Comprueba en Ajustes si el fabricante ofrece una actualización."
            )
        }
        if (s != null && s.percent >= 90) {
            r += Finding(
                FindingCode.STORAGE_FULL, RiskLevel.INFO, FindingKind.PREVENTIVE_INFO,
                "Almacenamiento casi lleno (${s.percent}%)",
                "Con poco espacio libre las actualizaciones pueden fallar."
            )
        }
        return r
    }

    private fun patchAgeDays(patch: String?): Long? = try {
        if (patch.isNullOrBlank()) null
        else ChronoUnit.DAYS.between(LocalDate.parse(patch), LocalDate.now())
    } catch (e: Exception) {
        null
    }

    private fun categoryLabel(category: Int): String = when (category) {
        ApplicationInfo.CATEGORY_GAME -> "Juegos"
        ApplicationInfo.CATEGORY_AUDIO -> "Audio"
        ApplicationInfo.CATEGORY_VIDEO -> "Vídeo"
        ApplicationInfo.CATEGORY_IMAGE -> "Imagen"
        ApplicationInfo.CATEGORY_NEWS -> "Noticias"
        else -> "Otra"
    }

    fun overallStatus(findings: List<Finding>): SecurityStatus = when {
        findings.any { it.level == RiskLevel.HIGH } -> SecurityStatus.AT_RISK
        findings.any { it.level == RiskLevel.MEDIUM } -> SecurityStatus.ATTENTION
        else -> SecurityStatus.GOOD
    }
}
