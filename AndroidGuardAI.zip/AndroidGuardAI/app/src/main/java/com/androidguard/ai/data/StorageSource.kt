package com.androidguard.ai.data

import android.os.Environment
import android.os.StatFs
import com.androidguard.ai.domain.StorageInfo

/** Almacenamiento interno (partición de datos) mediante StatFs. */
class StorageSource {
    fun read(): StorageInfo {
        val stat = StatFs(Environment.getDataDirectory().path)
        val total = stat.totalBytes
        val free = stat.availableBytes
        return StorageInfo(total = total, used = (total - free).coerceAtLeast(0L), free = free)
    }
}
