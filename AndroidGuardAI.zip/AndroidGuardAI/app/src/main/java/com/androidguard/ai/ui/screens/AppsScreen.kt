package com.androidguard.ai.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.androidguard.ai.domain.AppInfo
import com.androidguard.ai.domain.RiskAnalyzer
import com.androidguard.ai.ui.components.AppIcon
import com.androidguard.ai.ui.components.GuardCard
import com.androidguard.ai.ui.components.GuardList
import com.androidguard.ai.ui.components.ScreenTitle
import com.androidguard.ai.ui.components.Tag
import com.androidguard.ai.ui.components.TagRow
import com.androidguard.ai.ui.theme.GuardAmber
import com.androidguard.ai.ui.theme.GuardBlue
import com.androidguard.ai.ui.theme.GuardGreen
import com.androidguard.ai.ui.theme.GuardRed
import com.androidguard.ai.ui.theme.color
import com.androidguard.ai.viewmodel.GuardViewModel

private enum class AppFilter(val label: String) {
    USER("Usuario"), SYSTEM("Sistema"), ALL("Todas")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppsScreen(vm: GuardViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { vm.ensureAppsLoaded() }

    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf(AppFilter.USER) }

    val visible = remember(state.apps, query, filter) {
        state.apps
            .filter {
                when (filter) {
                    AppFilter.USER -> !it.isSystem
                    AppFilter.SYSTEM -> it.isSystem
                    AppFilter.ALL -> true
                }
            }
            .filter {
                query.isBlank() ||
                    it.name.contains(query, ignoreCase = true) ||
                    it.packageName.contains(query, ignoreCase = true)
            }
            .sortedWith(compareByDescending<AppInfo> { it.exposureScore }.thenBy { it.name.lowercase() })
    }

    GuardList {
        item { ScreenTitle("Auditoría de aplicaciones", "${visible.size} de ${state.apps.size} apps mostradas") }
        item {
            GuardCard {
                Text(
                    "Los permisos «concedidos» son hechos leídos del sistema; los indicadores son " +
                        "señales heurísticas y no prueban que una app sea maliciosa.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        if (state.appsLoading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        if (state.appsSkipped > 0) {
            item { Text("${state.appsSkipped} apps no pudieron consultarse por restricciones de Android.",
                color = GuardAmber, style = MaterialTheme.typography.bodySmall) }
        }
        items(state.appsNotes) { note ->
            Text("No disponible: $note", color = GuardAmber, style = MaterialTheme.typography.bodySmall)
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                placeholder = { Text("Buscar por nombre o paquete") }
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppFilter.values().forEach { f ->
                    FilterChip(
                        selected = filter == f,
                        onClick = { filter = f },
                        label = { Text(f.label) }
                    )
                }
            }
        }
        items(visible, key = { it.packageName }) { app -> AppCard(app) }
    }
}

@Composable
private fun AppCard(app: AppInfo) {
    var expanded by rememberSaveable(app.packageName) { mutableStateOf(false) }
    val findings = remember(app) { RiskAnalyzer.analyzeApp(app) }

    GuardCard(Modifier.clickable { expanded = !expanded }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon(app.packageName, Modifier.size(44.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(app.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(app.packageName, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("Versión ${app.versionName}", style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(
                if (expanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                contentDescription = null
            )
        }
        Spacer(Modifier.height(8.dp))
        TagRow {
            if (app.isSystem) Tag("Sistema", GuardBlue)
            app.sensitiveGranted.forEach { Tag("${it.label} ✓", GuardAmber) }
            (app.sensitiveRequested - app.sensitiveGranted).forEach {
                Tag("${it.label} (solicitado)", MaterialTheme.colorScheme.onSurfaceVariant)
            }
            app.specialActive.forEach { Tag(it.label, GuardRed) }
            findings.maxByOrNull { -it.level.ordinal }?.let { Tag(it.level.label, it.level.color()) }
        }

        if (expanded) {
            Spacer(Modifier.height(12.dp))
            DetailLine("Origen de instalación", app.origin.label + (app.installer?.let { " ($it)" } ?: ""))
            DetailLine("Permisos", "${app.requestedPermissions.size} solicitados · ${app.grantedPermissions.size} concedidos")
            if (app.unavailableChecks.isNotEmpty()) {
                DetailLine("No disponible en este dispositivo", app.unavailableChecks.joinToString(", "))
            }
            if (app.isSystem) {
                Text("App del sistema: no se evalúa con la heurística.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            findings.forEach { f ->
                Spacer(Modifier.height(8.dp))
                Tag("${f.level.label} · ${f.kind.label}", f.level.color())
                Text(f.title, fontWeight = FontWeight.SemiBold)
                Text(f.detail, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (app.requestedPermissions.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Text("Permisos solicitados", fontWeight = FontWeight.SemiBold)
                app.requestedPermissions.sorted().forEach { p ->
                    val ok = p in app.grantedPermissions
                    Text(
                        (if (ok) "✓ " else "✗ ") + p.removePrefix("android.permission."),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (ok) GuardGreen else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Column(Modifier.padding(vertical = 3.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}
