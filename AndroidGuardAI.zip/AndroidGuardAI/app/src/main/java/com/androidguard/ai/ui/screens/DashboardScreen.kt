package com.androidguard.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.androidguard.ai.domain.DeviceInfo
import com.androidguard.ai.domain.ScanSummary
import com.androidguard.ai.domain.SecurityStatus
import com.androidguard.ai.domain.formatDate
import com.androidguard.ai.ui.components.GuardCard
import com.androidguard.ai.ui.components.GuardList
import com.androidguard.ai.ui.components.ScanRadar
import com.androidguard.ai.ui.components.StatRow
import com.androidguard.ai.ui.components.Tag
import com.androidguard.ai.ui.components.TagRow
import com.androidguard.ai.ui.theme.GuardAmber
import com.androidguard.ai.ui.theme.GuardBlue
import com.androidguard.ai.ui.theme.GuardGreen
import com.androidguard.ai.ui.theme.GuardRed
import com.androidguard.ai.ui.theme.color
import com.androidguard.ai.ui.theme.usageColor
import com.androidguard.ai.viewmodel.GuardViewModel

@Composable
fun DashboardScreen(vm: GuardViewModel, onOpenReport: () -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { vm.refreshDevice() }

    val status: SecurityStatus = state.lastScan?.status
        ?: state.history.firstOrNull()?.status
        ?: SecurityStatus.UNKNOWN

    GuardList {
        item {
            Column {
                Text("ANDROID GUARD AI", style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("Análisis local: ningún dato sale de tu dispositivo",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item { DeviceCard(state.device) }
        item {
            GuardCard {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    ScanRadar(active = state.scanning) {
                        Icon(
                            Icons.Filled.Shield, contentDescription = null,
                            tint = status.color(), modifier = Modifier.size(72.dp)
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(status.label, style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold, color = status.color(), textAlign = TextAlign.Center)
                    if (state.lastScan == null && state.history.isNotEmpty()) {
                        Text("(resultado del último análisis guardado)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.height(12.dp))
                    if (state.scanning) {
                        LinearProgressIndicator(
                            progress = { state.scanProgress },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(state.scanStep, style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        state.scanError?.let {
                            Text(it, color = GuardRed, style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(6.dp))
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = vm::runScan,
                        enabled = !state.scanning,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("ANALIZAR DISPOSITIVO", fontWeight = FontWeight.Bold) }
                    if (state.lastScan != null && !state.scanning) {
                        OutlinedButton(onClick = onOpenReport, modifier = Modifier.fillMaxWidth()) {
                            Text("Ver informe final")
                        }
                    }
                }
            }
        }
        item {
            Text("Últimos análisis", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        if (state.history.isEmpty()) {
            item {
                GuardCard {
                    Text("Aún no hay análisis. Pulsa ANALIZAR DISPOSITIVO para realizar el primero.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            items(state.history.take(5)) { HistoryRow(it) }
        }
    }
}

@Composable
private fun DeviceCard(device: DeviceInfo?) {
    GuardCard {
        if (device == null) {
            Text("Leyendo información del dispositivo…", color = MaterialTheme.colorScheme.onSurfaceVariant)
            return@GuardCard
        }
        Text(device.displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Modelo ${device.model}", style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        StatRow("Versión de Android", "${device.androidRelease} (API ${device.sdkInt})")
        StatRow("Parche de seguridad", device.securityPatch ?: "No disponible")
        val battery = if (device.batteryPercent >= 0) "${device.batteryPercent}%" else "No disponible"
        StatRow("Batería", battery + if (device.charging) " · cargando" else "")
        if (device.batteryPercent >= 0) {
            Spacer(Modifier.height(4.dp))
            val batteryColor = if (device.batteryPercent <= 20 && !device.charging) GuardAmber else GuardGreen
            LinearProgressIndicator(
                progress = { device.batteryPercent / 100f },
                modifier = Modifier.fillMaxWidth(),
                color = batteryColor
            )
        }
    }
}

@Composable
private fun HistoryRow(s: ScanSummary) {
    GuardCard {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically) {
            Text(formatDate(s.timestamp), fontWeight = FontWeight.SemiBold)
            Tag(s.status.label, s.status.color())
        }
        Spacer(Modifier.height(6.dp))
        Text("${s.appsReviewed} apps · RAM ${s.ramPercent}% · Almacenamiento ${s.storagePercent}%",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(6.dp))
        TagRow {
            Tag("Alto ${s.high}", GuardRed)
            Tag("Medio ${s.medium}", GuardAmber)
            Tag("Bajo ${s.low}", GuardBlue)
            Tag("Info ${s.info}", MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
