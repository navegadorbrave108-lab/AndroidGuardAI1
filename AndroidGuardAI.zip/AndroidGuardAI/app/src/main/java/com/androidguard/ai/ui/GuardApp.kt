package com.androidguard.ai.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.androidguard.ai.ui.screens.AppsScreen
import com.androidguard.ai.ui.screens.DashboardScreen
import com.androidguard.ai.ui.screens.RamScreen
import com.androidguard.ai.ui.screens.ReportScreen
import com.androidguard.ai.ui.screens.SecurityScreen
import com.androidguard.ai.ui.screens.StorageScreen
import com.androidguard.ai.viewmodel.GuardViewModel

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private const val ROUTE_REPORT = "report"

private val tabs = listOf(
    Tab("dashboard", "Inicio", Icons.Filled.Home),
    Tab("storage", "Disco", Icons.Filled.Storage),
    Tab("ram", "RAM", Icons.Filled.Memory),
    Tab("apps", "Apps", Icons.Filled.Apps),
    Tab("security", "Seguridad", Icons.Filled.Shield)
)

@Composable
fun GuardApp(vm: GuardViewModel = viewModel()) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEach { tab ->
                    NavigationBarItem(
                        selected = currentRoute == tab.route,
                        onClick = {
                            nav.navigate(tab.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primary,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }
        }
    ) { padding ->
        val openReport: () -> Unit = { nav.navigate(ROUTE_REPORT) { launchSingleTop = true } }
        NavHost(
            navController = nav,
            startDestination = "dashboard",
            modifier = Modifier.padding(padding)
        ) {
            composable("dashboard") { DashboardScreen(vm, openReport) }
            composable("storage") { StorageScreen(vm) }
            composable("ram") { RamScreen(vm) }
            composable("apps") { AppsScreen(vm) }
            composable("security") { SecurityScreen(vm, openReport) }
            composable(ROUTE_REPORT) { ReportScreen(vm) }
        }
    }
}
