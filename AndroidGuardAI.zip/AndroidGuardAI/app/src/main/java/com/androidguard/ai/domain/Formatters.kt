package com.androidguard.ai.domain

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Formatea bytes (base 1024) como MB o GB. */
fun formatBytes(bytes: Long): String {
    val gb = bytes / (1024.0 * 1024.0 * 1024.0)
    return if (gb >= 1.0) {
        String.format(Locale.getDefault(), "%.2f GB", gb)
    } else {
        String.format(Locale.getDefault(), "%.0f MB", bytes / (1024.0 * 1024.0))
    }
}

fun formatDate(timestamp: Long): String =
    SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(timestamp))
