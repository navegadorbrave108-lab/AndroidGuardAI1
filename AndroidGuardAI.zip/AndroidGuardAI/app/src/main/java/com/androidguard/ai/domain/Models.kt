package com.androidguard.ai.domain

/** Niveles de resultado. El orden de declaración se usa para ordenar (más grave primero). */
enum class RiskLevel(val label: String) {
    HIGH("Riesgo alto"),
    MEDIUM("Riesgo medio"),
    LOW("Riesgo bajo"),
    INFO("Información preventiva")
}

/** Diferencia explícita entre hechos, sospechas y amenazas confirmadas. */
enum class FindingKind(val label: String) {
    GRANTED_PERMISSION("Permiso / privilegio concedido"),
    SUSPICIOUS_INDICATOR("Indicador sospechoso"),
    PREVENTIVE_INFO("Información preventiva"),
    /** Reservado: esta app no incluye motor antimalware, por lo que nunca genera este tipo. */
    CONFIRMED_THREAT("Amenaza confirmada")
}

enum class FindingCode {
    ACCESSIBILITY, DEVICE_ADMIN, OVERLAY, INSTALL_UNKNOWN, OUTSIDE_STORE_SENSITIVE,
    CATEGORY_MISMATCH, BACKGROUND_LOCATION, MANY_SENSITIVE, OUTSIDE_STORE_SUMMARY,
    PATCH_OLD, PATCH_UNKNOWN, NO_SCREEN_LOCK, USB_DEBUGGING, DEVELOPER_OPTIONS,
    TEST_KEYS, OLD_ANDROID, STORAGE_FULL
}

enum class SecurityStatus(val label: String) {
    UNKNOWN("Sin analizar"),
    GOOD("Sin indicadores relevantes"),
    ATTENTION("Atención recomendada"),
    AT_RISK("Revisión recomendada con prioridad")
}

enum class SensitiveCategory(val label: String, val permissions: Set<String>) {
    CAMERA("Cámara", setOf("android.permission.CAMERA")),
    MICROPHONE("Micrófono", setOf("android.permission.RECORD_AUDIO")),
    LOCATION(
        "Ubicación",
        setOf(
            "android.permission.ACCESS_FINE_LOCATION",
            "android.permission.ACCESS_COARSE_LOCATION",
            "android.permission.ACCESS_BACKGROUND_LOCATION"
        )
    ),
    CONTACTS(
        "Contactos",
        setOf(
            "android.permission.READ_CONTACTS",
            "android.permission.WRITE_CONTACTS",
            "android.permission.GET_ACCOUNTS"
        )
    ),
    SMS(
        "SMS",
        setOf(
            "android.permission.READ_SMS",
            "android.permission.SEND_SMS",
            "android.permission.RECEIVE_SMS",
            "android.permission.RECEIVE_MMS",
            "android.permission.RECEIVE_WAP_PUSH"
        )
    ),
    CALL_LOG(
        "Registro de llamadas",
        setOf(
            "android.permission.READ_CALL_LOG",
            "android.permission.WRITE_CALL_LOG",
            "android.permission.PROCESS_OUTGOING_CALLS"
        )
    )
}

enum class SpecialPrivilege(val label: String) {
    ACCESSIBILITY("Servicio de accesibilidad activo"),
    DEVICE_ADMIN("Administrador de dispositivo activo"),
    OVERLAY("Superposición de pantalla permitida"),
    INSTALL_UNKNOWN("Puede instalar apps desconocidas")
}

enum class InstallOrigin(val label: String) {
    KNOWN_STORE("Tienda conocida"),
    OUTSIDE_KNOWN_STORES("Fuera de tiendas conocidas"),
    SYSTEM_APP("App del sistema"),
    UNAVAILABLE("No disponible")
}

data class DeviceInfo(
    val displayName: String,
    val manufacturer: String,
    val model: String,
    val androidRelease: String,
    val sdkInt: Int,
    val securityPatch: String?,
    val batteryPercent: Int,
    val charging: Boolean,
    val screenLockSecure: Boolean?,
    val usbDebugging: Boolean?,
    val developerOptions: Boolean?,
    val testKeys: Boolean
)

data class StorageInfo(val total: Long, val used: Long, val free: Long) {
    val percent: Int get() = if (total > 0) ((used * 100) / total).toInt() else 0
}

data class MemoryStats(
    val total: Long,
    val available: Long,
    val used: Long,
    val lowMemory: Boolean
) {
    val percent: Int get() = if (total > 0) ((used * 100) / total).toInt() else 0
}

data class AppInfo(
    val name: String,
    val packageName: String,
    val versionName: String,
    val isSystem: Boolean,
    val category: Int,
    val origin: InstallOrigin,
    val installer: String?,
    val requestedPermissions: List<String>,
    val grantedPermissions: List<String>,
    val sensitiveRequested: Set<SensitiveCategory>,
    val sensitiveGranted: Set<SensitiveCategory>,
    val specialActive: Set<SpecialPrivilege>,
    /** Privilegios que no pudieron consultarse en este dispositivo. */
    val unavailableChecks: List<String>
) {
    /** Puntuación simple solo para ordenar la lista (no es una medida de riesgo). */
    val exposureScore: Int get() = specialActive.size * 3 + sensitiveGranted.size
}

data class Finding(
    val code: FindingCode,
    val level: RiskLevel,
    val kind: FindingKind,
    val title: String,
    val detail: String,
    val appName: String? = null,
    val packageName: String? = null
)

data class ScanResult(
    val timestamp: Long,
    val device: DeviceInfo,
    val storage: StorageInfo,
    val memory: MemoryStats,
    val appsReviewed: Int,
    val userApps: Int,
    val systemApps: Int,
    val appsSkipped: Int,
    val findings: List<Finding>,
    val status: SecurityStatus
) {
    fun count(level: RiskLevel): Int = findings.count { it.level == level }
}

data class ScanSummary(
    val timestamp: Long,
    val appsReviewed: Int,
    val high: Int,
    val medium: Int,
    val low: Int,
    val info: Int,
    val ramPercent: Int,
    val storagePercent: Int,
    val status: SecurityStatus
)
