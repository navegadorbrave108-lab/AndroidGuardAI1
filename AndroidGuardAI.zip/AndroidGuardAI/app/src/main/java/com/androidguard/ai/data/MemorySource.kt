package com.androidguard.ai.data

import android.app.ActivityManager
import android.content.Context
import com.androidguard.ai.domain.MemoryStats

/** RAM mediante ActivityManager.MemoryInfo. */
class MemorySource(private val context: Context) {
    fun read(): MemoryStats {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return MemoryStats(
            total = info.totalMem,
            available = info.availMem,
            used = (info.totalMem - info.availMem).coerceAtLeast(0L),
            lowMemory = info.lowMemory
        )
    }
}
