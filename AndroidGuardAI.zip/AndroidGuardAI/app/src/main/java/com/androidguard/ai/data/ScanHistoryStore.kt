package com.androidguard.ai.data

import android.content.Context
import com.androidguard.ai.domain.ScanSummary
import com.androidguard.ai.domain.SecurityStatus
import org.json.JSONArray
import org.json.JSONObject

/**
 * Guarda localmente (SharedPreferences privadas de la app) solo resúmenes numéricos
 * de los últimos análisis. No se guardan nombres de apps ni datos personales.
 */
class ScanHistoryStore(context: Context) {

    private val prefs = context.getSharedPreferences("scan_history", Context.MODE_PRIVATE)

    fun load(): List<ScanSummary> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ScanSummary(
                    timestamp = o.getLong("timestamp"),
                    appsReviewed = o.getInt("apps"),
                    high = o.getInt("high"),
                    medium = o.getInt("medium"),
                    low = o.getInt("low"),
                    info = o.getInt("info"),
                    ramPercent = o.getInt("ram"),
                    storagePercent = o.getInt("storage"),
                    status = runCatching { SecurityStatus.valueOf(o.getString("status")) }
                        .getOrDefault(SecurityStatus.UNKNOWN)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun add(summary: ScanSummary): List<ScanSummary> {
        val updated = (listOf(summary) + load()).take(MAX_ENTRIES)
        val arr = JSONArray()
        updated.forEach { s ->
            arr.put(
                JSONObject()
                    .put("timestamp", s.timestamp)
                    .put("apps", s.appsReviewed)
                    .put("high", s.high)
                    .put("medium", s.medium)
                    .put("low", s.low)
                    .put("info", s.info)
                    .put("ram", s.ramPercent)
                    .put("storage", s.storagePercent)
                    .put("status", s.status.name)
            )
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
        return updated
    }

    private companion object {
        const val KEY = "entries"
        const val MAX_ENTRIES = 10
    }
}
