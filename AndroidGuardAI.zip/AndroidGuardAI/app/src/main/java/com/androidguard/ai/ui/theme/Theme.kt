package com.androidguard.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.androidguard.ai.domain.RiskLevel
import com.androidguard.ai.domain.SecurityStatus

val GuardBackground = Color(0xFF050B18)
val GuardBackgroundEnd = Color(0xFF07152B)
val GuardSurface = Color(0xFF0D1727)
val GuardSurfaceHigh = Color(0xFF16263F)
val GuardGreen = Color(0xFF00E5A0)
val GuardBlue = Color(0xFF2E9BFF)
val GuardAmber = Color(0xFFFFB84D)
val GuardRed = Color(0xFFFF5C6C)
val GuardTextPrimary = Color(0xFFE8F0FF)
val GuardTextSecondary = Color(0xFF8DA2C0)

private val GuardColors = darkColorScheme(
    primary = GuardGreen,
    onPrimary = Color(0xFF002114),
    secondary = GuardBlue,
    onSecondary = Color(0xFF001B33),
    tertiary = GuardAmber,
    background = GuardBackground,
    onBackground = GuardTextPrimary,
    surface = GuardSurface,
    onSurface = GuardTextPrimary,
    surfaceVariant = GuardSurfaceHigh,
    onSurfaceVariant = GuardTextSecondary,
    error = GuardRed,
    outline = Color(0xFF2A3D5A)
)

@Composable
fun AndroidGuardTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = GuardColors,
        typography = Typography(),
        content = content
    )
}

fun RiskLevel.color(): Color = when (this) {
    RiskLevel.HIGH -> GuardRed
    RiskLevel.MEDIUM -> GuardAmber
    RiskLevel.LOW -> GuardBlue
    RiskLevel.INFO -> GuardTextSecondary
}

fun SecurityStatus.color(): Color = when (this) {
    SecurityStatus.GOOD -> GuardGreen
    SecurityStatus.ATTENTION -> GuardAmber
    SecurityStatus.AT_RISK -> GuardRed
    SecurityStatus.UNKNOWN -> GuardBlue
}

fun usageColor(percent: Int): Color = when {
    percent >= 85 -> GuardRed
    percent >= 70 -> GuardAmber
    else -> GuardGreen
}
