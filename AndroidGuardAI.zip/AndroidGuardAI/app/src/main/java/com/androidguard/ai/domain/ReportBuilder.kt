package com.androidguard.ai.domain

data class ReportSection(val title: String, val lines: List<String>)

data class Report(val title: String, val sections: List<ReportSection>) {
    fun toPlainText(): String = buildString {
        appendLine(title)
        appendLine()
        sections.forEach { section ->
            appendLine(section.title.uppercase())
            section.lines.forEach { appendLine(it) }
            appendLine()
        }
    }.trim()
}

object ReportBuilder {

    fun build(scan: ScanResult): Report {
        val d = scan.device
        val general = ReportSection(
            "Estado general del dispositivo",
            listOf(
                "Dispositivo: ${d.displayName} (${d.model})",
                "Android: ${d.androidRelease} (API ${d.sdkInt})",
                "Parche de seguridad: ${d.securityPatch ?: "no disponible"}",
                "Batería: ${if (d.batteryPercent >= 0) "${d.batteryPercent}%" else "no disponible"}" +
                    if (d.charging) " (cargando)" else "",
                "Estado de seguridad: ${scan.status.label}",
                "Análisis realizado: ${formatDate(scan.timestamp)}"
            )
        )
        val m = scan.memory
        val ram = ReportSection(
            "Consumo de RAM",
            listOf(
                "Total: ${formatBytes(m.total)}",
                "Usada: ${formatBytes(m.used)} (${m.percent}%)",
                "Disponible: ${formatBytes(m.available)}",
                if (m.lowMemory) "El sistema indica memoria baja." else "El sistema no indica memoria baja."
            )
        )
        val s = scan.storage
        val storage = ReportSection(
            "Consumo de almacenamiento",
            listOf(
                "Total (partición de datos): ${formatBytes(s.total)}",
                "Ocupado: ${formatBytes(s.used)} (${s.percent}%)",
                "Disponible: ${formatBytes(s.free)}"
            )
        )
        val apps = ReportSection(
            "Aplicaciones revisadas",
            buildList {
                add("Total consultadas: ${scan.appsReviewed}")
                add("Instaladas por el usuario (evaluadas): ${scan.userApps}")
                add("Del sistema (no evaluadas con heurística): ${scan.systemApps}")
                if (scan.appsSkipped > 0) add("No consultables por restricciones de Android: ${scan.appsSkipped}")
            }
        )

        val findingLines = buildList {
            add(
                "Alto: ${scan.count(RiskLevel.HIGH)} · Medio: ${scan.count(RiskLevel.MEDIUM)} · " +
                    "Bajo: ${scan.count(RiskLevel.LOW)} · Preventivo: ${scan.count(RiskLevel.INFO)}"
            )
            add("Amenazas confirmadas: 0 (esta app no incluye motor antimalware; los indicadores no prueban que algo sea malicioso).")
            scan.findings.filter { it.level != RiskLevel.INFO }.forEach { f ->
                val who = f.appName?.let { " — $it" } ?: ""
                add("• [${f.level.label}] ${f.title}$who")
            }
        }
        val findings = ReportSection("Hallazgos de seguridad", findingLines)
        val recs = ReportSection("Recomendaciones", recommendations(scan).map { "• $it" })

        return Report("ANDROID GUARD AI — Informe del dispositivo", listOf(general, ram, storage, apps, findings, recs))
    }

    private fun recommendations(scan: ScanResult): List<String> {
        val out = mutableListOf<String>()
        fun names(code: FindingCode): String =
            scan.findings.filter { it.code == code }.mapNotNull { it.appName }.distinct().take(6).joinToString(", ")
        fun has(code: FindingCode) = scan.findings.any { it.code == code }

        if (has(FindingCode.ACCESSIBILITY)) out += "Abre Ajustes > Accesibilidad y desactiva los servicios que no reconozcas (${names(FindingCode.ACCESSIBILITY)})."
        if (has(FindingCode.DEVICE_ADMIN)) out += "Revisa Ajustes > Seguridad > Apps de administración del dispositivo y desactiva las que no necesites (${names(FindingCode.DEVICE_ADMIN)})."
        if (has(FindingCode.OVERLAY)) out += "Revisa Ajustes > Apps > Acceso especial > Mostrar sobre otras apps (${names(FindingCode.OVERLAY)})."
        if (has(FindingCode.INSTALL_UNKNOWN)) out += "Revisa Ajustes > Apps > Acceso especial > Instalar apps desconocidas (${names(FindingCode.INSTALL_UNKNOWN)})."
        if (has(FindingCode.OUTSIDE_STORE_SENSITIVE)) out += "Comprueba el origen de estas apps y desinstala las que no reconozcas: ${names(FindingCode.OUTSIDE_STORE_SENSITIVE)}."
        if (has(FindingCode.CATEGORY_MISMATCH)) out += "Revoca SMS, contactos o registro de llamadas a estas apps si no los necesitan: ${names(FindingCode.CATEGORY_MISMATCH)}."
        if (has(FindingCode.BACKGROUND_LOCATION)) out += "Cambia la ubicación a «solo mientras se usa la app» en: ${names(FindingCode.BACKGROUND_LOCATION)}."
        if (has(FindingCode.PATCH_OLD)) out += "Busca actualizaciones en Ajustes > Sistema > Actualización de software; si ya no hay, considera cambiar de dispositivo."
        if (has(FindingCode.NO_SCREEN_LOCK)) out += "Configura un PIN, patrón o contraseña en Ajustes > Seguridad > Bloqueo de pantalla."
        if (has(FindingCode.USB_DEBUGGING)) out += "Desactiva la depuración USB en Opciones de desarrollador si no la usas."
        if (has(FindingCode.TEST_KEYS)) out += "Verifica que conoces el origen de la ROM instalada."
        if (scan.memory.percent >= 85) out += "La RAM está muy utilizada (${scan.memory.percent}%): cierra apps en segundo plano o reinicia el teléfono."
        if (scan.storage.percent >= 85) out += "El almacenamiento está casi lleno (${scan.storage.percent}%): elimina archivos y apps que no uses."
        if (out.isEmpty()) out += "No hay acciones urgentes. Mantén Android y tus apps actualizados y repite el análisis periódicamente."
        return out
    }
}
