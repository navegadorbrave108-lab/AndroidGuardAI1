package com.androidguard.ai.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.androidguard.ai.domain.formatBytes
import com.androidguard.ai.ui.components.CircularGauge
import com.androidguard.ai.ui.components.GuardCard
import com.androidguard.ai.ui.components.GuardList
import com.androidguard.ai.ui.components.ScreenTitle
import com.androidguard.ai.ui.components.StatRow
import com.androidguard.ai.ui.components.Tag
import com.androidguard.ai.ui.theme.GuardRed
import com.androidguard.ai.ui.theme.usageColor
import com.androidguard.ai.viewmodel.GuardViewModel

@Composable
fun RamScreen(vm: GuardViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    // Las métricas se actualizan cada vez que se abre el módulo.
    LaunchedEffect(Unit) { vm.refreshMemory() }
    val m = state.memory

    GuardList {
        item { ScreenTitle("Memoria RAM", "Datos de ActivityManager.MemoryInfo") }
        item {
            GuardCard {
                if (m == null) {
                    Text("Consultando memoria…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularGauge(
                            progress = m.percent / 100f,
                            color = usageColor(m.percent),
                            centerText = "${m.percent}%",
                            subText = "en uso"
                        )
                        if (m.lowMemory) Tag("El sistema indica memoria baja", GuardRed)
                    }
                    StatRow("RAM total", formatBytes(m.total))
                    StatRow("RAM utilizada", formatBytes(m.used), usageColor(m.percent))
                    StatRow("RAM disponible", formatBytes(m.available))
                }
            }
        }
        item {
            OutlinedButton(onClick = vm::refreshMemory, modifier = Modifier.fillMaxWidth()) {
                Text("Actualizar métricas")
            }
        }
        item {
            Text(
                "Android gestiona la RAM de forma dinámica: es normal que una parte esté ocupada por " +
                    "cachés que el sistema libera cuando hace falta.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
