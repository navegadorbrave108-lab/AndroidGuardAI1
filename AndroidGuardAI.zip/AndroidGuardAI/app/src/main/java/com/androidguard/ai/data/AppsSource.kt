package com.androidguard.ai.data

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.AppOpsManager
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import android.view.accessibility.AccessibilityManager
import com.androidguard.ai.domain.AppInfo
import com.androidguard.ai.domain.InstallOrigin
import com.androidguard.ai.domain.SensitiveCategory
import com.androidguard.ai.domain.SpecialPrivilege

/** Audita las apps que Android permite consultar (QUERY_ALL_PACKAGES declarado en el manifiesto). */
class AppsSource(private val context: Context) {

    data class Result(
        val apps: List<AppInfo>,
        /** Apps que el sistema no permitió consultar. */
        val skipped: Int,
        /** Funciones que no están disponibles en este dispositivo. */
        val notes: List<String>
    )

    private val knownStores = setOf(
        "com.android.vending",
        "com.sec.android.app.samsungapps",
        "com.amazon.venezia",
        "com.huawei.appmarket",
        "com.xiaomi.mipicks",
        "com.heytap.market",
        "com.vivo.appstore",
        "org.fdroid.fdroid"
    )

    @Suppress("DEPRECATION")
    fun load(): Result {
        val pm = context.packageManager
        val notes = mutableListOf<String>()

        val a11yPackages = enabledAccessibilityPackages()
        if (a11yPackages == null) notes += "No se pudo consultar los servicios de accesibilidad activos."
        val adminPackages = activeAdminPackages()
        if (adminPackages == null) notes += "No se pudo consultar los administradores de dispositivo."
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager
        if (appOps == null) notes += "No se pudo consultar los permisos especiales (superposición, instalación)."

        val installed = try {
            pm.getInstalledApplications(0)
        } catch (e: Exception) {
            notes += "Android no permitió listar las aplicaciones instaladas."
            emptyList<ApplicationInfo>()
        }

        var skipped = 0
        val apps = ArrayList<AppInfo>(installed.size)
        for (ai in installed) {
            try {
                apps += buildAppInfo(pm, ai, a11yPackages, adminPackages, appOps)
            } catch (e: Exception) {
                skipped++
            }
        }
        return Result(apps.sortedBy { it.name.lowercase() }, skipped, notes)
    }

    @Suppress("DEPRECATION")
    private fun buildAppInfo(
        pm: PackageManager,
        ai: ApplicationInfo,
        a11y: Set<String>?,
        admins: Set<String>?,
        appOps: AppOpsManager?
    ): AppInfo {
        val pkg = ai.packageName
        val pi: PackageInfo = pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS)
        val requested: List<String> = pi.requestedPermissions?.toList() ?: emptyList()
        val flags: IntArray? = pi.requestedPermissionsFlags
        val granted = requested.filterIndexed { index, _ ->
            flags != null && index < flags.size &&
                (flags[index] and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0
        }

        val isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
        val sensitiveRequested = SensitiveCategory.values()
            .filter { cat -> requested.any { it in cat.permissions } }.toSet()
        val sensitiveGranted = SensitiveCategory.values()
            .filter { cat -> granted.any { it in cat.permissions } }.toSet()

        val unavailable = mutableListOf<String>()
        val special = mutableSetOf<SpecialPrivilege>()

        if (a11y != null && pkg in a11y) special += SpecialPrivilege.ACCESSIBILITY
        if (admins != null && pkg in admins) special += SpecialPrivilege.DEVICE_ADMIN

        if (Manifest.permission.SYSTEM_ALERT_WINDOW in requested) {
            val mode = opMode(appOps, AppOpsManager.OPSTR_SYSTEM_ALERT_WINDOW, ai.uid, pkg)
            when {
                mode == null -> unavailable += "Superposición de pantalla"
                mode == AppOpsManager.MODE_ALLOWED -> special += SpecialPrivilege.OVERLAY
                mode == AppOpsManager.MODE_DEFAULT &&
                    Manifest.permission.SYSTEM_ALERT_WINDOW in granted -> special += SpecialPrivilege.OVERLAY
            }
        }
        if (Manifest.permission.REQUEST_INSTALL_PACKAGES in requested) {
            val mode = opMode(appOps, "android:request_install_packages", ai.uid, pkg)
            when {
                mode == null -> unavailable += "Instalación de apps desconocidas"
                mode == AppOpsManager.MODE_ALLOWED -> special += SpecialPrivilege.INSTALL_UNKNOWN
            }
        }

        val installerResult = runCatching { installerOf(pm, pkg) }
        val installer = installerResult.getOrNull()
        val origin = when {
            isSystem -> InstallOrigin.SYSTEM_APP
            installerResult.isFailure -> InstallOrigin.UNAVAILABLE
            installer != null && installer in knownStores -> InstallOrigin.KNOWN_STORE
            else -> InstallOrigin.OUTSIDE_KNOWN_STORES
        }

        return AppInfo(
            name = pm.getApplicationLabel(ai).toString(),
            packageName = pkg,
            versionName = pi.versionName ?: "—",
            isSystem = isSystem,
            category = ai.category,
            origin = origin,
            installer = installer,
            requestedPermissions = requested,
            grantedPermissions = granted,
            sensitiveRequested = sensitiveRequested,
            sensitiveGranted = sensitiveGranted,
            specialActive = special,
            unavailableChecks = unavailable
        )
    }

    @Suppress("DEPRECATION")
    private fun installerOf(pm: PackageManager, pkg: String): String? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            pm.getInstallSourceInfo(pkg).installingPackageName
        } else {
            pm.getInstallerPackageName(pkg)
        }

    private fun opMode(appOps: AppOpsManager?, op: String, uid: Int, pkg: String): Int? {
        if (appOps == null) return null
        return try {
            appOps.unsafeCheckOpNoThrow(op, uid, pkg)
        } catch (e: Exception) {
            null
        }
    }

    private fun enabledAccessibilityPackages(): Set<String>? = try {
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .mapNotNull { it.resolveInfo?.serviceInfo?.packageName }
            .toSet()
    } catch (e: Exception) {
        null
    }

    private fun activeAdminPackages(): Set<String>? = try {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        (dpm.activeAdmins ?: emptyList()).map { it.packageName }.toSet()
    } catch (e: Exception) {
        null
    }
}
