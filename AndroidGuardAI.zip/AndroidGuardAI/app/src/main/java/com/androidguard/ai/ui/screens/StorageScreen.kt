package com.androidguard.ai.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.androidguard.ai.domain.formatBytes
import com.androidguard.ai.ui.components.CircularGauge
import com.androidguard.ai.ui.components.GuardCard
import com.androidguard.ai.ui.components.GuardList
import com.androidguard.ai.ui.components.ScreenTitle
import com.androidguard.ai.ui.components.StatRow
import com.androidguard.ai.ui.theme.usageColor
import com.androidguard.ai.viewmodel.GuardViewModel

@Composable
fun StorageScreen(vm: GuardViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { vm.refreshStorage() }
    val s = state.storage

    GuardList {
        item { ScreenTitle("Almacenamiento", "Partición de datos del almacenamiento interno") }
        item {
            GuardCard {
                if (s == null) {
                    Text("Consultando almacenamiento…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularGauge(
                            progress = s.percent / 100f,
                            color = usageColor(s.percent),
                            centerText = "${s.percent}%",
                            subText = "utilizado"
                        )
                    }
                    StatRow("Total", formatBytes(s.total))
                    StatRow("Ocupado", formatBytes(s.used), usageColor(s.percent))
                    StatRow("Disponible", formatBytes(s.free))
                }
            }
        }
        item {
            Text(
                "El total corresponde a la partición de datos visible para las apps; puede ser menor " +
                    "que la capacidad comercial del teléfono porque el sistema reserva espacio.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
