# Reglas de ProGuard/R8 (la compilación debug no minimiza el código).
