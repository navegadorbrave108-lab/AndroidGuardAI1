# ANDROID GUARD AI

App Android nativa (Kotlin + Jetpack Compose + Material 3, MVVM) que analiza el estado del dispositivo:
almacenamiento, RAM, aplicaciones instaladas y permisos, con una evaluación heurística de seguridad.

- Sin root. Sin permiso INTERNET: ningún dato sale del dispositivo.
- Único permiso declarado: `QUERY_ALL_PACKAGES` (instalación) para poder listar las apps.
- Los resultados provienen de API oficiales de Android; no hay datos simulados.
- Los hallazgos son **indicadores**, no veredictos: la app no incluye motor antimalware.

## Compilar en la nube (GitHub Actions)

1. Sube todo el contenido de esta carpeta a un repositorio de GitHub (rama `main`).
2. Pestaña **Actions** → workflow **Build Android APK (Debug)** (se lanza solo con cada subida;
   también puedes usar **Run workflow**).
3. Al terminar en verde, abre la ejecución y descarga el artefacto **AndroidGuardAI-debug-apk**
   (viene dentro de un .zip con `app-debug.apk`).
4. En el teléfono: extrae el .zip, abre `app-debug.apk` y permite «Instalar apps desconocidas»
   para el navegador o gestor de archivos que uses.

## Estructura

```
.github/workflows/android-apk.yml   CI: JDK 17 + Gradle Wrapper + assembleDebug + upload-artifact
app/src/main/java/com/androidguard/ai/
  data/       fuentes de datos (dispositivo, almacenamiento, RAM, apps, historial local)
  domain/     modelos, RiskAnalyzer (heurística), ReportBuilder
  viewmodel/  GuardViewModel (StateFlow)
  ui/         tema, componentes, pantallas y navegación inferior
```

## Notas

- El APK es **debug**: se firma con la clave debug estándar de Android (no es privada).
  Para una versión release firmada, guarda el keystore y sus contraseñas en *GitHub Secrets*; nunca en el repositorio.
- `gradle-wrapper.jar` es un binario que no se incluye en este paquete: si falta, el workflow lo
  genera automáticamente con Gradle 8.9 antes de compilar.
